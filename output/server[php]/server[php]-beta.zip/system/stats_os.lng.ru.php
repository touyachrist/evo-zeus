<?php if(!defined('__CP__'))die();
define('LNG_STATS',              'Статистика по OC');
define('LNG_STATS_TOTAL_INFO',   'OC для ботнета:');
define('LNG_STATS_OSLIST_EMPTY', '-- Пусто --');
?>